These icons are thanks to:

http://www.webalys.com/design-interface-application-framework.php
