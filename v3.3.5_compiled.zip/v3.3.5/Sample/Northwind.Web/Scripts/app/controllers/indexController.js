﻿'use strict';

northwindApp.controller('indexController',
    function ($scope)
    {
    });