﻿'use strict';

northwindApp.controller('homeController',
    function ($scope)
    {
    });