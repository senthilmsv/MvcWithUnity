﻿
/// ** INTEGRATION TEST INSTRUCTIONS**
/// Please verify the the Northwind.Test/app.config connection string is correct for your environment

///** UNIT TEST INSTRUCTIONS**
/// No Database needed, these test use a FakeDbContext, please do not use these test that test persistance, they are 
/// for testing business logic.
