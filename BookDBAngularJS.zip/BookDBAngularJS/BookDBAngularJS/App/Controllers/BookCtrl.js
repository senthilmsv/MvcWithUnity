﻿angular.module('AngularDemo.Book', [])
.controller('BookCtrl', ['$scope', '$http', function ($scope, $http) {
    $scope.model = [];
    $http.get('/book/indexvm').success(function (data) {
        $scope.model = data;
    });
}]);