﻿using System;
using System.Diagnostics;
using System.IO;
using System.Web;
using System.Web.Mvc;
using SampleGlimpseApp.DB;
using SampleGlimpseApp.Entities;

namespace SampleGlimpseApp.Controllers
{
    public class EmployeeController : Controller
    {
        DataClass clsData = new DataClass();
       
        // GET: /Employee/
        public ActionResult EmployeeList(string deptId)
        {
            Trace.WriteLine("EmployeeList action starts here");
            //int did = (!string.IsNullOrEmpty(deptId)) ? Convert.ToInt32(deptId) : 0;
            if (!string.IsNullOrEmpty(deptId) && !string.Equals(deptId,"All"))
            {
                var emp = clsData.EmployeesListByDept(deptId);
                emp = null;
               return View(emp);
            }
            else
            {
                var emp = clsData.EmployeesList();
                return View(emp);
            }
            
            Trace.WriteLine("EmployeeList action ends here");
           
        }

     // GET: /Employee/Details/5
        public ActionResult EmplyeeDetailById(int id)
        {
            var emp = clsData.EmployeeDetail(id);
            return View(emp);
        }
        [HttpPost]
        public ActionResult EmplyeeDetailById(int id, Employee emp)
        {
            var result = clsData.EditEmployee(emp);
            if (result > 0)
            {
                return RedirectToAction("EmployeeList");
            }
            else
            {
                return View();
            }
        }
       
        // GET: /Employee/Create
        public ActionResult AddEmployee()
        {
            var emp = new Employee();
            return View(emp);
        }

      
        // POST: /Employee/Create
        [HttpPost]
        public ActionResult AddEmployee(Employee emp, HttpPostedFileBase profilePic1, string gd)
        {
            try
            {
                emp.Gender = gd;

                if (profilePic1 != null)
                {
                    var fileName = Path.GetFileName(profilePic1.FileName);
                    var path = Path.Combine(Server.MapPath("~/Images"), fileName);
                    if (!System.IO.File.Exists(path))
                    {
                        profilePic1.SaveAs(path);
                        ModelState.Clear();
                    }
                    emp.ProfilePic = fileName;
                }
                else
                {
                    emp.ProfilePic = Convert.ToString(TempData["ProfilePic"]);
                }
               // emp.ProfilePic = (profilePic1 != null) ? profilePic1.FileName : string.Empty;
                int result = clsData.AddEmployee(emp);
                // TODO: Add insert logic here
                if (result > 0)
                {
                    TempData["msg"] = "New employee record added successfully.";
                    return RedirectToAction("EmployeeList");
                }
                else
                {
                    return View();
                }
            }
            catch
            {
                return View();
            }
        }

        // GET: /Employee/Edit/5
        public ActionResult EditEmployee(int id)
        {
            var emp = clsData.EmployeeDetail(id);
            return View(emp);
        }

        
        // POST: /Employee/Edit/5
        [HttpPost]
        public ActionResult EditEmployee(int id, Employee emp, HttpPostedFileBase profilePic1,string gd)
        {
            try
            {
                emp.EmpId = id;
                emp.Gender = gd;
                if (profilePic1 != null)
                {
                    var fileName = Path.GetFileName(profilePic1.FileName);
                    var path = Path.Combine(Server.MapPath("~/Images"), fileName);
                    if (!System.IO.File.Exists(path))
                    {
                        profilePic1.SaveAs(path);
                        ModelState.Clear();
                    }
                    emp.ProfilePic = fileName;
                }
                else
                {
                    emp.ProfilePic = Convert.ToString(TempData["ProfilePic"]);
                }
                int result = clsData.EditEmployee(emp);
                // TODO: Add update logic here
                if (result > 0)
                {
                    TempData["msg"] = "Employee record updated successfully.";
                    return RedirectToAction("EmployeeList");
                }
                else
                {
                    return View();
                }
            }
            catch
            {
                return View();
            }
        }

        // GET: /Employee/Delete/5
        public ActionResult Delete(int id)
        {
            int result = clsData.DeleteEmployee(id);
            if (result > 0)
            {
                TempData["msg"] = "Employee record deleted successfully.";
                return RedirectToAction("EmployeeList");
            }
            else
            {
                return View();
            }
            
        }

       // GET: /Employee/Edit/5
        public ActionResult Ajax()
        {
            return View();
        }
        public ActionResult AngularJs()
        {
          return View();
        }
    }
}
