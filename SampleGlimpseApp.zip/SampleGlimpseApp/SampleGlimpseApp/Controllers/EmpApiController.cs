﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleGlimpseApp.DB;
using SampleGlimpseApp.Entities;

namespace SampleGlimpseApp.Controllers
{
    public class EmpApiController : ApiController
    {
        DataClass data = new DataClass();
        // GET api/values
        public IEnumerable<Employee> Get()
        {
            var emp = data.EmployeesList();
            return emp;
        }

        public IEnumerable<Employee> Get(string dept)
        {
            var emp = data.EmployeesListByDept(dept);
            return emp;
        }
    }
}
