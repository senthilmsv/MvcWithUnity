﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Antlr.Runtime;

namespace SampleGlimpseApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";
            NewRelic.Api.Agent.NewRelic.NoticeError(new Exception("This is a custom ex. message."));
            var req = new RequestClass() {Id = 100, Name = "Rakhi"};
            var res = new ResponseClass() { Id = 100, Name = "Rakhi",Address = "Noida"};
            var keyValues= new List<KeyValuePair<string, object>>(){ new KeyValuePair<string,object>("req",req),new KeyValuePair<string, object>("res",res)};
            NewRelic.Api.Agent.NewRelic.RecordCustomEvent("Custom Log error", keyValues);
            NewRelic.Api.Agent.NewRelic.AddCustomParameter("req", req.ToString());
            NewRelic.Api.Agent.NewRelic.AddCustomParameter("res", res.ToString());
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        class RequestClass
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }
        class ResponseClass
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string Address { get; set; }
        }
    }
}
