﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleGlimpseApp.Entities
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string Address { get; set; }
        public List<string> AddressList { get { return new List<string>() { "Delhi", "Faridabad", "Gaziabad", "Gurgaon", "Noida" }; } }
        public int Salary { get; set; }
        public string ProfilePic { get; set; }
        public string Department { get; set; }
        public List<string> DepartmentList { get { return new List<string>() { "All","IT", "HR", "QA" }; } }
        public string Gender { get; set; }
    }
}
