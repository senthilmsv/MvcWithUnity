﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SampleGlimpseApp.Entities;

namespace SampleGlimpseApp.DB
{
    public class DataClass
    {
        public List<Employee> EmployeesList()
        {
            var lstEmployees = new List<Employee>();
            using (var db = new SampleDBEntities())
            {
                var emps = db.tblEmployees.ToList();
                emps.ForEach(emp => lstEmployees.Add(
                    new Employee()
                    {
                        EmpId = emp.empid,
                        EmpName = emp.empname,
                        Salary = emp.empSalary.GetValueOrDefault(),
                        Gender = emp.empGender,
                        ProfilePic = emp.empImage,
                        Address = emp.empAddrress,
                        Department = emp.dept
                    }));
            }
            return lstEmployees;
        }
        public List<Employee> EmployeesListByDept(string dept)
        {
            var lstEmployees = new List<Employee>();
            using (var db = new SampleDBEntities())
            {
                var emps = db.sp_GetEmployeesByDept(dept).ToList();
                emps.ForEach(emp => lstEmployees.Add(
                    new Employee()
                    {
                        EmpId = emp.empid,
                        EmpName = emp.empname,
                        Salary = emp.empSalary.GetValueOrDefault(),
                        Gender = emp.empGender,
                        ProfilePic = emp.empImage,
                        Address = emp.empAddrress,
                        Department = emp.dept
                    }));
            }
            return lstEmployees;
        }
        public Employee EmployeeDetail(int id)
        {
            var employee = new Employee();
            using (var db = new SampleDBEntities())
            {
                var emp = db.tblEmployees.Where(ee => ee.empid == id).FirstOrDefault();
                if (emp != null)
                {
                    employee.EmpId = emp.empid;
                    employee.EmpName = emp.empname;
                    employee.Salary = emp.empSalary.GetValueOrDefault();
                    employee.Gender = emp.empGender;
                    employee.ProfilePic = emp.empImage;
                    employee.Address = emp.empAddrress;
                    employee.Department = emp.dept;
                }
            }
            return employee;
        }

        /// <summary>
        /// Add Employee
        /// </summary>
        /// <param name="employee"></param>
        /// <returns></returns>
        public int AddEmployee(Employee employee)
        {
            int result = 0;
            using (var db = new SampleDBEntities())
            {
                var emp = new tblEmployee();
                if (employee != null)
                {
                    emp.empname = employee.EmpName;
                    emp.empSalary = employee.Salary;
                    emp.empGender = employee.Gender;
                    emp.empImage = employee.ProfilePic;
                    emp.empAddrress = employee.Address;
                    emp.dept = employee.Department;
                    db.tblEmployees.Add(emp);
                    var saveChanges = db.SaveChanges();
                    result = saveChanges;
                }
            }
            return result;
        }
        public int EditEmployee(Employee employee)
        {
            int result = 0;
            using (var db = new SampleDBEntities())
            {
                var emp = db.tblEmployees.FirstOrDefault(ee => ee.empid == employee.EmpId);
                if (emp != null)
                {
                    emp.empname = employee.EmpName;
                    emp.empSalary = employee.Salary;
                    emp.empGender = employee.Gender;
                    emp.empImage = employee.ProfilePic;
                    emp.empAddrress = employee.Address;
                    emp.dept = employee.Department;
                    db.tblEmployees.Add(emp);
                    result = db.SaveChanges();
                   }
            }
            return result;
        }

        public int DeleteEmployee(int id)
        {
            int result = 0;
            using (var db = new SampleDBEntities())
            {
                var emp = db.tblEmployees.FirstOrDefault(ee => ee.empid == id);
                if (emp != null)
                {
                db.tblEmployees.Remove(emp);
                result = db.SaveChanges();
                }
            }
            return result;
        }
    }
}
